#!/bin/bash

# Define the number of peers
NUM_PEERS=$1

# Check if number of peers is at least 3
if [[ $NUM_PEERS -lt 3 ]]; then
  echo "Number of peers must be at least 3."
  exit 1
fi

# Create a directory for configuration files
CONFIG_DIR="./config"
mkdir -p "$CONFIG_DIR"

# Start the Docker Compose YAML file
echo "version: '3'" > docker-compose.yml
echo "services:" >> docker-compose.yml

peer_ids=""

# Loop to define each peer service and generate configuration files
for (( id=1; id<=NUM_PEERS; id++ )); do
  # Define the port for this peer
  port=$((20000 + id))
  grpc_port=$((6500 + id))
  peer_ids+="peer${id}, "

  # Create a list of other peers in the format id:hostname:port
  peers=""
  for (( other_id=1; other_id<=NUM_PEERS; other_id++ )); do
    if [[ $other_id -ne $id ]]; then
      # Calculate the port for the other peer
      other_port=$((20000 + other_id))
      # Use the service name as the hostname
      peers+="${other_port},"
    fi
  done
  # Remove the trailing comma
  peers=${peers%,}

  # Create the application.properties file for this peer
  CONFIG_FILE="$CONFIG_DIR/application-peer${id}.properties"
  cat <<EOF > "$CONFIG_FILE"
# Configuration for peer $id
id=$id
port=$port
peers=$peers
grpc.server.port=$grpc_port
server.port=$port
grpc.server.insecure=true
server.ssl.enabled=false
EOF
  echo "Created configuration file: $CONFIG_FILE"

  # Add service to the docker-compose.yml file for this peer
  cat <<EOF >> docker-compose.yml
  peer$id:
    image: peer_app
    container_name: peer$id
    # command: --id $id --port $port --peers $peers "org.example.Main"
    ports:
      - "$port:$port"
    volumes:
      - $CONFIG_FILE:/app/application.properties
    healthcheck:
      test: ["CMD", "netstat", "-tlnp"]
      interval: 10s
      retries: 10
      start_period: 10s
EOF
done

# Add client_app service to the docker-compose.yml file
client_peers=""
for (( id=1; id<=NUM_PEERS; id++ )); do
  # Calculate the port for the peer
  port=$((20000 + id))
  # Add the peer in the format peer_name:peer_port
  client_peers+="${port},"
done
# Remove the trailing comma
client_peers=${client_peers%,}
client_port=$((20000 + NUM_PEERS + 1))
# Uncomment this block to add a client service
cat <<EOF >> docker-compose.yml
  client_app:
    image: client_app
    ports: 
      - "$client_port:$client_port"
    container_name: client_app
    command: --peers $client_peers
    depends_on:
      peer1:
        condition: service_healthy
      peer2:
        condition: service_healthy
      peer3:
        condition: service_healthy
    restart: always
    volumes:
      - ./logs:/logs
EOF

client_grpc_port=$((6500 + NUM_PEERS + 1))
# Create the application.properties file for the client
  CONFIG_FILE="$CONFIG_DIR/application-client.properties"
  cat <<EOF > "$CONFIG_FILE"
# Configuration for client
peers.ports.list=$client_peers
grpc.server.port=$client_grpc_port
port=$client_port
grpc.server.insecure=true
server.ssl.enabled=false
EOF
  echo "Created configuration file: $CONFIG_FILE"

echo "Generated docker-compose.yml and configuration files for $NUM_PEERS peers."
